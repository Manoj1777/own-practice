package com.manoj.com.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.manoj.com.model.Employee;

// @Controller
@RestController // @controller +  	@ResponseBody

public class EmployeeController {
   
	 
	@GetMapping("/employees")
	 public String getEmploees()
	 {
		return "display the list of employees";
	}
	@GetMapping("/employees/{id}")
	public String getEmployee(@PathVariable("id") Long id)
	{
		return "fetching the employee dtails from the id "+id;
	}
	
     // localhost:8080/employees?id=20
	@DeleteMapping("employees")
	public String deleteEmployees(@RequestParam("id") int id)
	{
	   return "deleting employees details for id "+id;	
	}
	@PostMapping("/employees")
	public String saveEmployee(@RequestBody Employee employee)
	{
	   return "saving the employee details to the database "+employee;	
	}
	@PutMapping("/employees/{id}")
	public Employee updateEmploees( @PathVariable("id") Long id , @RequestBody Employee employee)
	{
		 System.out.println("updating  !!  "+id);
		 return employee;
	}
	
	
	
	
	
	
	
}
