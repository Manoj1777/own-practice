package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRep;

@Service
public class BookService {
       
	@Autowired
	  private BookRep bookRep;
	
	// get all
	public List<Book> milBook() 
	{
		return bookRep.findAll();
	}
	// get single
	
	public Optional<Book> milYekBook(int id)
	{
		return bookRep.findById(id);
	}
	// cfreate book
	
	public void bnaye( Book book)
	{
		bookRep.save(book);
	}
	
	// update book
	public void updateKro(int id, Book book)
	{
		book.setId(id);
		bookRep.save(book);
	}
	// delete Boook
	public void delete(int id)
	{
		bookRep.deleteById(id);
	}
	
	// delete all
	public void deletAllKro() 
	{
		bookRep.deleteAll();
	}
	
	
}
