package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Author;
import com.example.demo.repository.AuthorRepository;

@Service
public class AuthorService {
    
	@Autowired
	private AuthorRepository authorRepository;
	
	// get all
	public List<Author>  getAllAuth()
	{
		return authorRepository.findAll();
	}
	
	// get single
	public Optional<Author> getSinAuth(int authorId)
	{
		
		return authorRepository.findById(authorId);
	}
	
	//  create author
	
	public void createAuth( Author author)
	{
	 
	       authorRepository.save(author);
	}
	
	// update 
	
	public void updateAut(int authorId, Author author)
	{
		author.setAuthorId(authorId);
		   authorRepository.save(author);
	}
	
	// delete 
	
	public void deleteAuth(int authorId) 
	{
	    authorRepository.deleteById(authorId);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	 
}
