package com.example.demo.restController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Author;
import com.example.demo.service.AuthorService;

@RestController
public class AuthorRestController {
   
	@Autowired
	private AuthorService authorService;
	
	// get all
	@GetMapping("/authors")
	public List<Author> get()
	{
		return authorService.getAllAuth();
	}
	
	// get single
	@GetMapping("/author/{authorId}")
	public Optional<Author> getSi( @PathVariable("authorId")  int authorId) 
	{
		return authorService.getSinAuth(authorId);
	}
	
	// create 
	
	@PostMapping("/author")
	public void cre( @RequestBody Author author)
	{
		authorService.createAuth(author);
	}
	
	// update
	@PutMapping("/author/{authorId}")
	public void  updat(@PathVariable("authorId") int authorId, @RequestBody Author author) 
	{
		 authorService.updateAut(authorId, author);
	}
	
	// delete 
	@DeleteMapping("/author/{authorId}")
	public void de( @PathVariable("authorId") int  authorId)
	{
		authorService.deleteAuth(authorId);
	}
	
	
	
}
